package com.Neosoft.service.Impl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserServiceImplTest {

    @Test
    void registerNewUser() {
    }

    @Test
    void saveUser() {
    }

    @Test
    void getSingleUser() {
    }

    @Test
    void getAllUser() {
    }

    @Test
    void updateUser() {
    }

    @Test
    void deleteUser() {
    }
}